//
//  self_ios_sdk.h
//  self-ios-sdk
//
//  Created by DO HAI VU on 06/09/2023.
//

#import <Foundation/Foundation.h>

//! Project version number for self_ios_sdk.
FOUNDATION_EXPORT double self_ios_sdkVersionNumber;

//! Project version string for self_ios_sdk.
FOUNDATION_EXPORT const unsigned char self_ios_sdkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <self_ios_sdk/PublicHeader.h>


